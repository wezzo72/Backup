NUCLEAR DOWNLOAD
A free preservation copy of every page
20 November 2026

Dr Richard William McLean
Public names: Barran Dodger / Barran Resonance Dodger
Website: The Witness Remains — The Great Reckoning

FINDING AID · NOT A COURT · NOT A VERDICT

This file was made so the testimony can be kept if the website is altered, taken down, or the witness is silenced. It is free. There is no payment and no gate. Download it. Keep it. A copy in your hands is harder to erase than a page on a server.

573 pages were printed to PDF. 0 failed. Each PDF is the words of that page as published on 20 November 2026, with the page address in the header. The time stamp records when this preservation copy was sealed. It is not a Bitcoin calendar proof. SHA-256 fingerprints are in HASHES.sha256.

Hash-list fingerprint:
e3a1d1a54e68f5be8d784c21ec9bb3019a7482453c321cc995fb6401b8b50f65

sha256sum -c HASHES.sha256

A preserved page is evidence of what the page said. It is not, by itself, a finding.
